package com.cg.spring.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cg.spring.beans.MerchantInfo;
import com.cg.spring.beans.MerchantOrders;
import com.cg.spring.beans.ProductBean;
import com.cg.spring.service.IService;

@RestController
public class Springcontroller {
	static MerchantInfo merchant; 
	public ProductBean product;
	@Autowired
	IService service;
	@RequestMapping("/profile")
	public Optional<MerchantInfo> displayprofile() {
		String email="abcd@gmail.com";
		return service.displayInfo(email);
	
	}
	@RequestMapping("/orders")
	public List<MerchantOrders> displayorders(){
		String email="abcd@gmail.com";
		return service.displayorders(email);
	}
	@RequestMapping("/inventory")
	public List<ProductBean> displayinventory(){
		String email="abcd@gmail.com";
		return service.displayinventory(email);
	}
	@RequestMapping("/addproduct")
	public String addproduct(@RequestParam String name,@RequestParam int id,@RequestParam String price,@RequestParam String des,@RequestParam String type,@RequestParam String email) {
		System.out.println("bongu");
		product=new ProductBean();
		product.setProduct_id(id);
		product.setProduct_name(name);
		product.setProduct_price(price);
		product.setProduct_description(des);
		product.setProduct_type(type);
		product.setMerchant_email(email);
		System.out.println(product);
		return service.addproduct(product);
		
	}
	@RequestMapping("/deleteproducts")
	public String deleteproduct(@RequestParam int id) {
		return service.deleteproduct(id);
		
	}

}
