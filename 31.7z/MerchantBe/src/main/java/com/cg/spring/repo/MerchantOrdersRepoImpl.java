package com.cg.spring.repo;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.cg.spring.beans.MerchantOrders;

@Repository
public class MerchantOrdersRepoImpl implements IMerchantOrdersRepo{

	@Autowired
	@PersistenceContext
	EntityManager manager;
	@Override
	public List<MerchantOrders> displayorders(String email) {
		List<MerchantOrders> list = new ArrayList<>();
		Query q = manager.createQuery("from MerchantOrders WHERE merchant_email='"+email+"'");
		list=q.getResultList();
		
		return list;
		
		
	}
	
	

}
