package com.cg.spring.beans;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="inventory")
public class MerchantInventory {
@Id
@GeneratedValue(strategy=GenerationType.AUTO)
public String product_id;
public String product_name;
public int quantity_available;
public String merchant_email;
public String getMerchant_email() {
	return merchant_email;
}
public void setMerchant_email(String merchant_name) {
	this.merchant_email = merchant_name;
}
public String getProduct_id() {
	return product_id;
}
public void setProduct_id(String product_id) {
	this.product_id = product_id;
}
public String getProduct_name() {
	return product_name;
}
public void setProduct_name(String product_name) {
	this.product_name = product_name;
}
public int getQuantity_available() {
	return quantity_available;
}
public void setQuantity_available(int quantity_available) {
	this.quantity_available = quantity_available;
}

}
