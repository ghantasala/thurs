package com.cg.spring.repo;

import java.util.List;

import com.cg.spring.beans.ProductBean;

public interface IIMerchantInventoryRepo {

	List<ProductBean> displayinnventory(String email);

}
