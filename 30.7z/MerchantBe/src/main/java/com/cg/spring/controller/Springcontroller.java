package com.cg.spring.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cg.spring.beans.MerchantInfo;
import com.cg.spring.beans.MerchantOrders;
import com.cg.spring.beans.ProductBean;
import com.cg.spring.service.IService;

@RestController
public class Springcontroller {
	static MerchantInfo merchant; 
	public ProductBean product;
	@Autowired
	IService service;
	@RequestMapping("/profile")
	public Optional<MerchantInfo> displayprofile() {
		String email="abcd@gmail.com";
		return service.displayInfo(email);
	
	}
	@RequestMapping("/orders")
	public List<MerchantOrders> displayorders(){
		String email="abcd@gmail.com";
		return service.displayorders(email);
	}
	@RequestMapping("/inventory")
	public List<ProductBean> displayinventory(){
		String email="abcd@gmail.com";
		return service.displayinventory(email);
	}
	@RequestMapping(path="/addproduct")
	public void addproduct(@RequestParam String name,@RequestParam Integer id,@RequestParam String price,@RequestParam String des,@RequestParam String type,@RequestParam String email) {
		product.setProduct_id(id);
		product.setProduct_name(name);
		product.setProduct_price(price);
		product.setProduct_description(des);
		product.setProduct_type(type);
		product.setMerchant_email(email);
		/*System.out.println(product);*/
		 service.addproduct(product);
		
	}
	@RequestMapping(path="/deleteproduct/{id}",method=RequestMethod.DELETE)
	public void deleteproduct(@RequestParam int id) {
		service.deleteproduct(id);
	}

}
