package com.cg.spring.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.servlet.ModelAndView;

import com.cg.spring.beans.MerchantInfo;
import com.cg.spring.beans.MerchantOrdeers;

@RestController
public class FrontEndController {
	@RequestMapping("/profile")
	public ModelAndView show()
	{
		
		RestTemplate rt=new RestTemplate();
		MerchantInfo merchant=rt.getForObject("http://localhost:8686/profile",MerchantInfo.class );
		return new ModelAndView("profile","merchant" , merchant);
	}
	@RequestMapping("/orders")
	public ModelAndView display() {
		RestTemplate st=new RestTemplate();
		List<MerchantOrdeers> ord= st.getForObject("http://localhost:8686/orders",ArrayList.class );
		return  new ModelAndView("orders","od" ,ord);
	}
	@RequestMapping("/add")
	public void addproduct(@RequestParam String name,@RequestParam Integer id,@RequestParam String price,@RequestParam String des,@RequestParam String type,@RequestParam String email) {
		RestTemplate st=new RestTemplate();
		st.put("http://localhost:8686/addproduct?product_name="+name+"&product_id="+id+ "&product_price="+price+ "&description=" +des+ "&product_type=" +type+ "&merchant_email="+email,String.class);
	//	String result= st.getForObject("http://localhost:8686/addproduct/"+id+"/"+name+"/"+price+"/"+des+"/"+type+"/"+email+"/",String.class );


	}

}
