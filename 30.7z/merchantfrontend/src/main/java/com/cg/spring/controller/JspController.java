package com.cg.spring.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.servlet.ModelAndView;

import com.cg.spring.beans.MerchantOrdeers;

@Controller
public class JspController {
	@RequestMapping("/")
	public ModelAndView inventory() {
		RestTemplate st=new RestTemplate();
		List<MerchantOrdeers> ivt= st.getForObject("http://localhost:8686/inventory",ArrayList.class );
		return  new ModelAndView("inventory","inventory" ,ivt);
	}
	@RequestMapping("/addproduct")
	public String addproduct() {
		return "addproduct";
	}
	
}
